package com.prank.gameproject;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    CardView cardHome;
    CardView cardAbout;
    CardView cardGame;
    CardView cardLeaderboard;
    CardView cardCredit;
    private final android.widget.Toast Toast;

    public MainActivity(android.widget.Toast toast) {
        Toast = toast;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardHome = findViewById(R.id.cardHome);
        cardAbout = findViewById(R.id.cardAbout);
        cardGame = findViewById(R.id.cardGame);
        cardLeaderboard = findViewById(R.id.cardLeaderboard);
        cardCredit = findViewById(R.id.cardCredit);

        cardHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Home Clicked");
            }
        });
        cardAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showToast("Chat Clicked");
            }
        });
        cardGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showToast("Profile Clicked");
            }
        });
        cardLeaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showToast("Widget Clicked");
            }
        });
        cardCredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showToast("Settings Clicked");
            }
        });

    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}