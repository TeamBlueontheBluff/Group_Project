package com.prank.gameproject

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class Leaderboard : AppCompatActivity() {

    private val PREF_KEY_SCORE = "SCORE"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        val sharedPreferences = getPreferences(Context.MODE_PRIVATE)

        val scoreListView: ListView = findViewById(R.id.scoreListView)

        // Retrieve scores from SharedPreferences
        val scores: MutableList<Int> = getScores(sharedPreferences)

        // Sort scores in descending order (highest score on top)
        scores.sortDescending()

        // Create an ArrayAdapter to display scores in a ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, scores.map { it.toString() })
        scoreListView.adapter = adapter
    }

    private fun getScores(sharedPreferences: SharedPreferences): MutableList<Int> {
        val scores = mutableListOf<Int>()

        // Retrieve scores from SharedPreferences as integers
        val scoreSet = sharedPreferences.getStringSet(PREF_KEY_SCORE, emptySet()) ?: emptySet()

        // Convert strings to integers and add them to the scores list
        for (scoreString in scoreSet) {
            val score = scoreString.toIntOrNull()
            if (score != null) {
                scores.add(score)
            }
        }

        return scores
    }
}
