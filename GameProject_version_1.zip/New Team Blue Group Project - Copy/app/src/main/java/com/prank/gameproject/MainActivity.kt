package com.prank.gameproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cardAbout: CardView = findViewById(R.id.cardAbout)
        val cardGame: CardView = findViewById(R.id.cardGame)
        val cardLeaderboard: CardView = findViewById(R.id.cardLeaderboard)
        val cardCredit: CardView = findViewById(R.id.cardCredit)

        cardAbout.setOnClickListener {
            openAboutActivity()
        }

        cardGame.setOnClickListener {
            openGameActivity()
        }

        cardLeaderboard.setOnClickListener {
            openLeaderboardActivity()
        }

        cardCredit.setOnClickListener {
            openCreditActivity()
        }
    }

    private fun openAboutActivity() {
        val intent = Intent(this, About::class.java)
        startActivity(intent)
    }

    private fun openGameActivity() {
        val intent = Intent(this, Game::class.java)
        startActivity(intent)
    }

    private fun openLeaderboardActivity() {
        val intent = Intent(this, Leaderboard::class.java)
        startActivity(intent)
    }

    private fun openCreditActivity() {
        val intent = Intent(this, Credit::class.java)
        startActivity(intent)
    }
}
