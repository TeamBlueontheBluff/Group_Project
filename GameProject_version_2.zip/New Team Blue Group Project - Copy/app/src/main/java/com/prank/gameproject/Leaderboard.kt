package com.prank.gameproject

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class Leaderboard : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        val scoreListView: ListView = findViewById(R.id.scoreListView)

        // Hardcoded list of scores and player IDs
        val leaderboardEntries = listOf(
            LeaderboardEntry("JAH", 50),
            LeaderboardEntry("ABH", 10),
            LeaderboardEntry("MYT", 20),
            LeaderboardEntry("DTH", 50),
            LeaderboardEntry("PRO", 50)
            // Add more entries as needed
        )

        // Sort entries in descending order of scores
        val sortedEntries = leaderboardEntries.sortedByDescending { it.score }

        // Create an ArrayAdapter to display scores in a ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            sortedEntries.map { "${it.playerId}: ${it.score}" })
        scoreListView.adapter = adapter
    }
}
