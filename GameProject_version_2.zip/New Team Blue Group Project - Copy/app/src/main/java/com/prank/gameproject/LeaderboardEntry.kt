package com.prank.gameproject

data class LeaderboardEntry(val playerId: String, val score: Int)
