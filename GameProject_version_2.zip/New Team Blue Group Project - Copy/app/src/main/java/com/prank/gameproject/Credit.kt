package com.prank.gameproject

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Credit : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit)

        val creditTextView: TextView = findViewById(R.id.creditTextView)

        // Set the text explaining how credits work
        val creditExplanation = """
            Welcome to the Credit Section!

            The "Guess Word" app allows users to guess a five-letter word by inputting their guesses,
            receiving feedback on correctness, and accumulating points based on the number of attempts,
            with the highest scores displayed in a leaderboard.
            If guess is true in 1 credit = 30;
            If guess is true in 2 credit = 20;
            If guess is true in 3 credit = 10;
            Thank you for using our app and enjoy the experience!
        """.trimIndent()

        creditTextView.text = creditExplanation
    }
}
