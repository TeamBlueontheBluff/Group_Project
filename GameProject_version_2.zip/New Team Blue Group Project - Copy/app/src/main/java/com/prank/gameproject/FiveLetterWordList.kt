package com.example.wordle

// author: calren
object FiveLetterWordList {
    // List of most common 5 letter words from: https://7esl.com/5-letter-words/
    val fiveLetterWords =
        "blaze,quirk,fable,grime,scone,hound,pluck,radar,vixen,dwelt,quirky,jumbo,knoll,moose,petty,rumba,zebra,twiggy,yodel,joust,fluke,nexus,peppy,hying,vinyl,whiff,quote,flint,quirk,bulky,blush,ferry,glide,ovary,trunk,vexed,zoned,lyric,dusty,tramp,optic,shush,koala,salsa,queen,kilns,fjord,jacks,plumb,gypsy"

    // Returns a list of four letter words as a list
    fun getAllFiveLetterWords(): List<String> {
        return fiveLetterWords.split(",")
    }

    // Returns a random four letter word from the list in all caps
    fun getRandomFiveLetterWord(): String {
        val allWords = getAllFiveLetterWords()
        val randomNumber = (0..allWords.size).shuffled().last()
        return allWords[randomNumber].uppercase()
    }
}
